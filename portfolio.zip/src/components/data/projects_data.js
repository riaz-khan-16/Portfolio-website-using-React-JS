import COVID from '../../assets/projects_images/COVID.jpg'


const data_projects = [
    {
        name: 'COVID 19 tracker',
        image: COVID,
        deployed_url: 'https://covid-19-tracker-by-sumit.web.app/',
        github_url: 'https://github.com/Dey-Sumit/covid-19-tracker',
        category: ['react.js']
    }
    
]

export default data_projects;